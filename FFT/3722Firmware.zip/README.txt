When extracting these files, use the "extract" command (rather than drag-and-drop or cut-and-paste) to ensure that the directory structure is preserved. The files should appear as follows:

(dir)
|
|-- Debug (dir)
|-- settings (dir)
	|-- fft_r2.dni => project file
	|-- fft_r2.fmt => project file
	|-- fft_r2.ini => project file
|-- iomaxq200x.h => source file
|-- maxqfft.h => source file
|-- maxqfft.c => source file
|-- fft_r2.dep => project file
|-- fft_r2.ewd => project file
|-- fft_r2.ewp => project file 
|-- fft_r2.eww => project file
|-- schematic.bmp => schematic for fft project 
|-- fftgraph.exe => MS Windows application for viewing FFT results
|-- README.txt => this file

The workspace file (fft_r2.eww) can then be opened and compiled with IAR Embedded Workbench for MAXQ

